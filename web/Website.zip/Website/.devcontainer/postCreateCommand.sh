npm i -g pnpm

pnpm i