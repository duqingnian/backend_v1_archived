<script lang="ts">
	import { Metadata } from "$lib";
</script>

<Metadata title="Files • Themes" image="themes" />

todo
