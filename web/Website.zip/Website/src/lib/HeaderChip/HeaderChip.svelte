<span class="header-chip">
	<slot />
</span>

<style lang="scss">
	@use "./HeaderChip";
</style>
