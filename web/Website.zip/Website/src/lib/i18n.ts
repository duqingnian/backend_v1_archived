export const defaultI18nValues = {
	values: {
		FilesName: "Files",
	},
};
