#!/usr/bin/python
import os
os.system("./bin/console fos:user:create admin --super-admin");
